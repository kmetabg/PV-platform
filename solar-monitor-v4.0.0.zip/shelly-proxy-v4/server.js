/**
 * Shelly Proxy Server v4 - with SQLite Database + User Authentication
 * 
 * Features:
 * - SQLite database for efficient storage
 * - User authentication (register/login)
 * - Per-user configuration storage
 * - Smart downsampling (detailed recent, averaged old)
 * - Automatic data retention management
 */

const http = require('http');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');

// Configuration
const CONFIG = {
    port: process.env.PORT || 3000,
    defaultDevice: process.env.SHELLY_IP || '',
    dbPath: process.env.DB_PATH || path.join(__dirname, 'data', 'solar_history.db'),
    settingsPath: process.env.SETTINGS_PATH || path.join(__dirname, 'data', 'settings.json'),
    
    // Timezone (IANA format, e.g., 'Europe/Sofia', 'America/New_York')
    timezone: process.env.TIMEZONE || 'UTC',
    
    // JWT-like token settings
    tokenSecret: process.env.TOKEN_SECRET || 'shelly-solar-secret-key-change-in-production',
    tokenExpiry: 30 * 24 * 60 * 60 * 1000, // 30 days
    
    // Data retention settings
    retention: {
        raw: 24,           // Keep raw data for 24 hours
        hourly: 7,         // Keep hourly averages for 7 days
        daily: 365         // Keep daily averages for 1 year
    },
    
    // Background fetching settings
    backgroundFetch: {
        enabled: process.env.AUTO_FETCH === 'true' || true,
        interval: parseInt(process.env.FETCH_INTERVAL) || 10000,
        shellyIp: process.env.SHELLY_IP || '',
        pvComponentId: parseInt(process.env.PV_COMPONENT_ID) || 200,
        gridComponentId: parseInt(process.env.GRID_COMPONENT_ID) || 204,
        consumptionComponentId: parseInt(process.env.CONSUMPTION_COMPONENT_ID) || 205,
        batterySOCComponentId: parseInt(process.env.BATTERY_SOC_COMPONENT_ID) || 203,
        batteryPowerComponentId: parseInt(process.env.BATTERY_POWER_COMPONENT_ID) || 201
    }
};

// Ensure data directory exists
const fs = require('fs');
const dataDir = path.dirname(CONFIG.dbPath);
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

// Load settings from file (overrides ENV)
function loadSettings() {
    try {
        console.log(`[Settings] Looking for settings at: ${CONFIG.settingsPath}`);
        console.log(`[Settings] __dirname is: ${__dirname}`);
        
        // List data directory contents
        const dataDir = path.dirname(CONFIG.settingsPath);
        if (fs.existsSync(dataDir)) {
            const files = fs.readdirSync(dataDir);
            console.log(`[Settings] Files in data dir: ${files.join(', ') || '(empty)'}`);
        } else {
            console.log(`[Settings] Data directory does not exist: ${dataDir}`);
        }
        
        if (fs.existsSync(CONFIG.settingsPath)) {
            const content = fs.readFileSync(CONFIG.settingsPath, 'utf8');
            console.log(`[Settings] File contents: ${content}`);
            const settings = JSON.parse(content);
            if (settings.timezone) {
                CONFIG.timezone = settings.timezone;
                console.log(`[Settings] Loaded timezone: ${CONFIG.timezone}`);
            }
        } else {
            console.log(`[Settings] No settings file found, using default: ${CONFIG.timezone}`);
        }
    } catch (error) {
        console.error('[Settings] Failed to load:', error.message);
    }
}

function saveSettings() {
    try {
        // Ensure data directory exists
        const dataDir = path.dirname(CONFIG.settingsPath);
        console.log(`[Settings] Data dir: ${dataDir}`);
        
        if (!fs.existsSync(dataDir)) {
            console.log(`[Settings] Creating data directory: ${dataDir}`);
            fs.mkdirSync(dataDir, { recursive: true });
        }
        
        const settings = { timezone: CONFIG.timezone };
        const settingsJson = JSON.stringify(settings, null, 2);
        console.log(`[Settings] Writing to ${CONFIG.settingsPath}: ${settingsJson}`);
        
        fs.writeFileSync(CONFIG.settingsPath, settingsJson);
        
        // Verify the write
        if (fs.existsSync(CONFIG.settingsPath)) {
            const verify = fs.readFileSync(CONFIG.settingsPath, 'utf8');
            console.log(`[Settings] Verified file contents: ${verify}`);
        } else {
            console.error(`[Settings] ERROR: File does not exist after write!`);
        }
    } catch (error) {
        console.error('[Settings] Failed to save:', error.message);
        console.error('[Settings] Stack:', error.stack);
    }
}

// Load settings at startup
loadSettings();

// Timezone utility functions
function getLocalDate(timestamp = Date.now()) {
    // Get local date string in YYYY-MM-DD format for configured timezone
    const date = new Date(timestamp);
    try {
        const options = { timeZone: CONFIG.timezone, year: 'numeric', month: '2-digit', day: '2-digit' };
        const parts = new Intl.DateTimeFormat('en-CA', options).formatToParts(date);
        const year = parts.find(p => p.type === 'year').value;
        const month = parts.find(p => p.type === 'month').value;
        const day = parts.find(p => p.type === 'day').value;
        return `${year}-${month}-${day}`;
    } catch (error) {
        // Fallback to UTC if timezone is invalid
        return date.toISOString().split('T')[0];
    }
}

function getLocalTime(timestamp = Date.now()) {
    // Get local time string in HH:MM format for configured timezone
    const date = new Date(timestamp);
    try {
        const options = { timeZone: CONFIG.timezone, hour: '2-digit', minute: '2-digit', hour12: false };
        return new Intl.DateTimeFormat('en-GB', options).format(date);
    } catch (error) {
        return date.toISOString().slice(11, 16);
    }
}

function getLocalDatetime(timestamp = Date.now()) {
    // Get full local datetime for configured timezone
    const date = new Date(timestamp);
    try {
        const options = { 
            timeZone: CONFIG.timezone, 
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit',
            hour12: false 
        };
        return new Intl.DateTimeFormat('en-GB', options).format(date).replace(',', '');
    } catch (error) {
        return date.toISOString();
    }
}

function getStartOfLocalDay(timestamp = Date.now()) {
    // Get timestamp of start of day (00:00:00) in local timezone
    const dateStr = getLocalDate(timestamp);
    try {
        // Create date at midnight in local timezone
        const localMidnight = new Date(dateStr + 'T00:00:00');
        // Adjust for timezone offset
        const tzOffset = getTimezoneOffset();
        return Math.floor(localMidnight.getTime() / 1000) - (tzOffset * 60);
    } catch (error) {
        const d = new Date(timestamp);
        d.setHours(0, 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    }
}

function getTimezoneOffset() {
    // Get timezone offset in minutes from UTC
    try {
        const now = new Date();
        const utcDate = new Date(now.toLocaleString('en-US', { timeZone: 'UTC' }));
        const tzDate = new Date(now.toLocaleString('en-US', { timeZone: CONFIG.timezone }));
        return (tzDate - utcDate) / 60000;
    } catch (error) {
        return 0;
    }
}

// Initialize SQLite Database
const db = new Database(CONFIG.dbPath);
db.pragma('journal_mode = WAL');

// Create tables
db.exec(`
    -- Users table for authentication
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        salt TEXT NOT NULL,
        config TEXT DEFAULT '{}',
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    
    -- Plants table for multiple PV systems per user
    CREATE TABLE IF NOT EXISTS plants (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        location TEXT,
        capacity_kwp REAL,
        config TEXT DEFAULT '{}',
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    
    -- Sessions table for tokens
    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT UNIQUE NOT NULL,
        expires_at INTEGER NOT NULL,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    -- Raw power readings (kept for 24 hours)
    CREATE TABLE IF NOT EXISTS readings_raw (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plant_id INTEGER DEFAULT 1,
        timestamp INTEGER NOT NULL,
        pv_power REAL,
        grid_power REAL,
        consumption REAL,
        battery_soc REAL,
        battery_power REAL,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    
    -- Hourly averages (kept for 7 days)
    CREATE TABLE IF NOT EXISTS readings_hourly (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plant_id INTEGER DEFAULT 1,
        hour_timestamp INTEGER NOT NULL,
        pv_power_avg REAL,
        pv_power_max REAL,
        grid_power_avg REAL,
        consumption_avg REAL,
        consumption_max REAL,
        battery_soc_avg REAL,
        battery_power_avg REAL,
        sample_count INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    
    -- Daily totals and averages (kept for 1 year)
    CREATE TABLE IF NOT EXISTS readings_daily (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plant_id INTEGER DEFAULT 1,
        date TEXT NOT NULL,
        pv_energy_wh REAL,
        grid_import_wh REAL,
        grid_export_wh REAL,
        consumption_wh REAL,
        battery_charge_wh REAL,
        battery_discharge_wh REAL,
        pv_power_max REAL,
        consumption_max REAL,
        battery_soc_min REAL,
        battery_soc_max REAL,
        sample_count INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    
    -- Daily peaks table (15-minute averages)
    CREATE TABLE IF NOT EXISTS daily_peaks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plant_id INTEGER DEFAULT 1,
        date TEXT NOT NULL,
        peak_pv_power REAL DEFAULT 0,
        peak_pv_time TEXT,
        peak_grid_power REAL DEFAULT 0,
        peak_grid_time TEXT,
        peak_consumption_power REAL DEFAULT 0,
        peak_consumption_time TEXT,
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
    
    -- Create indexes
    CREATE INDEX IF NOT EXISTS idx_raw_timestamp ON readings_raw(timestamp);
    CREATE INDEX IF NOT EXISTS idx_raw_plant ON readings_raw(plant_id);
    CREATE INDEX IF NOT EXISTS idx_raw_plant_time ON readings_raw(plant_id, timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_hourly_timestamp ON readings_hourly(hour_timestamp);
    CREATE INDEX IF NOT EXISTS idx_hourly_plant ON readings_hourly(plant_id);
    CREATE INDEX IF NOT EXISTS idx_daily_date ON readings_daily(date);
    CREATE INDEX IF NOT EXISTS idx_daily_plant ON readings_daily(plant_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token);
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_plants_user ON plants(user_id);
    
    -- Unique indexes for multi-plant support
    CREATE UNIQUE INDEX IF NOT EXISTS idx_hourly_plant_time ON readings_hourly(plant_id, hour_timestamp);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_daily_plant_date ON readings_daily(plant_id, date);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_peaks_plant_date ON daily_peaks(plant_id, date);
`);

console.log('Database initialized');

// ============================================
// AUTHENTICATION HELPERS
// ============================================

function hashPassword(password, salt = null) {
    if (!salt) {
        salt = crypto.randomBytes(16).toString('hex');
    }
    const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
    return { hash, salt };
}

function generateToken() {
    return crypto.randomBytes(32).toString('hex');
}

function createSession(userId) {
    const token = generateToken();
    const expiresAt = Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60); // 30 days
    
    db.prepare(`INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)`).run(userId, token, expiresAt);
    
    // Clean up expired sessions
    db.prepare(`DELETE FROM sessions WHERE expires_at < ?`).run(Math.floor(Date.now() / 1000));
    
    return { token, expiresAt };
}

function validateToken(token) {
    if (!token) return null;
    
    const session = db.prepare(`
        SELECT s.*, u.id as user_id, u.email, u.config 
        FROM sessions s 
        JOIN users u ON s.user_id = u.id 
        WHERE s.token = ? AND s.expires_at > ?
    `).get(token, Math.floor(Date.now() / 1000));
    
    return session;
}

function getUserFromRequest(req) {
    // Check Authorization header
    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        return validateToken(token);
    }
    
    // Check query parameter
    const url = require('url');
    const parsedUrl = url.parse(req.url, true);
    if (parsedUrl.query.token) {
        return validateToken(parsedUrl.query.token);
    }
    
    return null;
}

// Auth statements
const authStatements = {
    getUserByEmail: db.prepare(`SELECT * FROM users WHERE email = ?`),
    createUser: db.prepare(`INSERT INTO users (email, password_hash, salt, config) VALUES (?, ?, ?, ?)`),
    updateUserConfig: db.prepare(`UPDATE users SET config = ?, updated_at = strftime('%s', 'now') WHERE id = ?`),
    getUserCount: db.prepare(`SELECT COUNT(*) as count FROM users`),
    deleteSession: db.prepare(`DELETE FROM sessions WHERE token = ?`)
};

// ============================================
// PREPARED STATEMENTS FOR DATA
// ============================================

const statements = {
    insertRaw: db.prepare(`
        INSERT INTO readings_raw (plant_id, timestamp, pv_power, grid_power, consumption, battery_soc, battery_power)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `),
    
    getRawByRange: db.prepare(`
        SELECT timestamp, pv_power, grid_power, consumption, battery_soc, battery_power
        FROM readings_raw
        WHERE plant_id = ? AND timestamp >= ? AND timestamp <= ?
        ORDER BY timestamp ASC
    `),
    
    getHourlyByRange: db.prepare(`
        SELECT hour_timestamp as timestamp, pv_power_avg as pv_power, grid_power_avg as grid_power, 
               consumption_avg as consumption, battery_soc_avg as battery_soc, battery_power_avg as battery_power
        FROM readings_hourly
        WHERE plant_id = ? AND hour_timestamp >= ? AND hour_timestamp <= ?
        ORDER BY hour_timestamp ASC
    `),
    
    getDailyByRange: db.prepare(`
        SELECT date, pv_energy_wh, grid_import_wh, grid_export_wh, consumption_wh,
               battery_charge_wh, battery_discharge_wh,
               pv_power_max, consumption_max, battery_soc_min, battery_soc_max
        FROM readings_daily
        WHERE plant_id = ? AND date >= ? AND date <= ?
        ORDER BY date ASC
    `),
    
    upsertHourly: db.prepare(`
        INSERT INTO readings_hourly (plant_id, hour_timestamp, pv_power_avg, pv_power_max, grid_power_avg, 
                                     consumption_avg, consumption_max, battery_soc_avg, battery_power_avg, sample_count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(plant_id, hour_timestamp) DO UPDATE SET
            pv_power_avg = (pv_power_avg * sample_count + excluded.pv_power_avg) / (sample_count + 1),
            pv_power_max = MAX(pv_power_max, excluded.pv_power_max),
            grid_power_avg = (grid_power_avg * sample_count + excluded.grid_power_avg) / (sample_count + 1),
            consumption_avg = (consumption_avg * sample_count + excluded.consumption_avg) / (sample_count + 1),
            consumption_max = MAX(consumption_max, excluded.consumption_max),
            battery_soc_avg = (battery_soc_avg * sample_count + excluded.battery_soc_avg) / (sample_count + 1),
            battery_power_avg = (COALESCE(battery_power_avg, 0) * sample_count + excluded.battery_power_avg) / (sample_count + 1),
            sample_count = sample_count + 1
    `),
    
    upsertDaily: db.prepare(`
        INSERT INTO readings_daily (plant_id, date, pv_energy_wh, grid_import_wh, grid_export_wh, consumption_wh,
                                   battery_charge_wh, battery_discharge_wh,
                                   pv_power_max, consumption_max, battery_soc_min, battery_soc_max, sample_count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(plant_id, date) DO UPDATE SET
            pv_energy_wh = pv_energy_wh + excluded.pv_energy_wh,
            grid_import_wh = grid_import_wh + excluded.grid_import_wh,
            grid_export_wh = grid_export_wh + excluded.grid_export_wh,
            consumption_wh = consumption_wh + excluded.consumption_wh,
            battery_charge_wh = COALESCE(battery_charge_wh, 0) + excluded.battery_charge_wh,
            battery_discharge_wh = COALESCE(battery_discharge_wh, 0) + excluded.battery_discharge_wh,
            pv_power_max = MAX(pv_power_max, excluded.pv_power_max),
            consumption_max = MAX(consumption_max, excluded.consumption_max),
            battery_soc_min = MIN(battery_soc_min, excluded.battery_soc_min),
            battery_soc_max = MAX(battery_soc_max, excluded.battery_soc_max),
            sample_count = sample_count + 1
    `),
    
    deleteOldRaw: db.prepare(`DELETE FROM readings_raw WHERE timestamp < ?`),
    deleteOldHourly: db.prepare(`DELETE FROM readings_hourly WHERE hour_timestamp < ?`),
    deleteOldDaily: db.prepare(`DELETE FROM readings_daily WHERE date < ?`),
    
    // Peak statements
    getPeakByDate: db.prepare(`SELECT * FROM daily_peaks WHERE plant_id = ? AND date = ?`),
    getPeaksByDateRange: db.prepare(`
        SELECT date, peak_pv_power, peak_pv_time, peak_grid_power, peak_grid_time, 
               peak_consumption_power, peak_consumption_time
        FROM daily_peaks
        WHERE plant_id = ? AND date >= ? AND date <= ?
        ORDER BY date ASC
    `),
    upsertPeak: db.prepare(`
        INSERT INTO daily_peaks (plant_id, date, peak_pv_power, peak_pv_time, peak_grid_power, peak_grid_time, 
                                 peak_consumption_power, peak_consumption_time, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'))
        ON CONFLICT(plant_id, date) DO UPDATE SET
            peak_pv_power = CASE WHEN excluded.peak_pv_power > peak_pv_power THEN excluded.peak_pv_power ELSE peak_pv_power END,
            peak_pv_time = CASE WHEN excluded.peak_pv_power > peak_pv_power THEN excluded.peak_pv_time ELSE peak_pv_time END,
            peak_grid_power = CASE WHEN excluded.peak_grid_power > peak_grid_power THEN excluded.peak_grid_power ELSE peak_grid_power END,
            peak_grid_time = CASE WHEN excluded.peak_grid_power > peak_grid_power THEN excluded.peak_grid_time ELSE peak_grid_time END,
            peak_consumption_power = CASE WHEN excluded.peak_consumption_power > peak_consumption_power THEN excluded.peak_consumption_power ELSE peak_consumption_power END,
            peak_consumption_time = CASE WHEN excluded.peak_consumption_power > peak_consumption_power THEN excluded.peak_consumption_time ELSE peak_consumption_time END,
            updated_at = strftime('%s', 'now')
    `),
    getRawByTimeRange: db.prepare(`
        SELECT pv_power, grid_power, consumption
        FROM readings_raw
        WHERE plant_id = ? AND timestamp > ? AND timestamp <= ?
    `),
    
    // Plant management
    getPlantsByUser: db.prepare(`SELECT * FROM plants WHERE user_id = ? ORDER BY id ASC`),
    getPlantById: db.prepare(`SELECT * FROM plants WHERE id = ?`),
    createPlant: db.prepare(`
        INSERT INTO plants (user_id, name, location, capacity_kwp, config) 
        VALUES (?, ?, ?, ?, ?)
    `),
    updatePlant: db.prepare(`
        UPDATE plants SET name = ?, location = ?, capacity_kwp = ?, config = ?, updated_at = strftime('%s', 'now')
        WHERE id = ? AND user_id = ?
    `),
    deletePlant: db.prepare(`DELETE FROM plants WHERE id = ? AND user_id = ?`),
    
    // Get latest reading for a plant
    getLatestReading: db.prepare(`
        SELECT timestamp, pv_power, grid_power, consumption, battery_soc, battery_power
        FROM readings_raw
        WHERE plant_id = ?
        ORDER BY timestamp DESC
        LIMIT 1
    `),
    
    // Get today's summary for a plant
    getTodaySummary: db.prepare(`
        SELECT * FROM readings_daily WHERE plant_id = ? AND date = ?
    `)
};

// Track last processed 15-min window per plant
const lastProcessedWindows = {};

// In-memory cache for latest readings (for fast home page loading)
const latestReadingsCache = {};

// Get the end time of the last completed 15-min window (aligned to :00, :15, :30, :45)
function getLastCompletedWindowEnd(timestamp) {
    const date = new Date(timestamp * 1000);
    const minutes = date.getMinutes();
    // Round DOWN to last 15-min boundary
    const windowMinute = Math.floor(minutes / 15) * 15;
    date.setMinutes(windowMinute, 0, 0);
    return Math.floor(date.getTime() / 1000);
}

// Get start of 15-min window from end time
function get15MinWindowStart(windowEnd) {
    return windowEnd - (15 * 60);
}

// Calculate and store peak for a completed 15-min window
function processPeakWindow(windowEnd, plantId = 1) {
    try {
        const windowStart = get15MinWindowStart(windowEnd);
        
        // Get all readings in this window for this plant
        const readings = statements.getRawByTimeRange.all(plantId, windowStart, windowEnd);
        
        if (readings.length === 0) {
            // No readings for this window - that's ok, just skip
            return;
        }
        
        // Calculate averages
        let sumPv = 0, sumGrid = 0, sumCons = 0;
        readings.forEach(r => {
            sumPv += r.pv_power || 0;
            sumGrid += Math.abs(r.grid_power || 0); // Use absolute value for grid
            sumCons += r.consumption || 0;
        });
        
        const avgPv = sumPv / readings.length;
        const avgGrid = sumGrid / readings.length;
        const avgCons = sumCons / readings.length;
        
        // Format time as HH:MM using local timezone
        const timeStr = getLocalTime(windowEnd * 1000);
        const dateStr = getLocalDate(windowEnd * 1000);
        
        // Store peak (will only update if higher than existing)
        statements.upsertPeak.run(plantId, dateStr, avgPv, timeStr, avgGrid, timeStr, avgCons, timeStr);
        
        console.log(`[${getLocalDatetime()}] Plant ${plantId} Peak ${timeStr}: PV=${avgPv.toFixed(0)}W Grid=${avgGrid.toFixed(0)}W Cons=${avgCons.toFixed(0)}W (${readings.length} samples)`);
    } catch (error) {
        console.error(`[${new Date().toISOString()}] Error processing peak window:`, error);
    }
}

// Check if we need to process a new 15-min window for a plant
function checkAndProcessPeakWindow(plantId = 1) {
    try {
        // Skip if not initialized yet for this plant
        if (!lastProcessedWindows[plantId]) return;
        
        const now = Math.floor(Date.now() / 1000);
        const lastCompletedWindow = getLastCompletedWindowEnd(now);
        
        // Process all missed windows (catch up)
        while (lastProcessedWindows[plantId] < lastCompletedWindow) {
            const nextWindow = lastProcessedWindows[plantId] + (15 * 60);
            if (nextWindow > lastCompletedWindow) break;
            
            processPeakWindow(nextWindow, plantId);
            lastProcessedWindows[plantId] = nextWindow;
        }
    } catch (error) {
        console.error(`[${new Date().toISOString()}] Peak window processing error:`, error);
    }
}

// Store a reading
// Current active plant ID for background fetching
let activeBackgroundPlantId = 1;

function storeReading(pv, grid, consumption, batterySoc, batteryPower = 0, plantId = 1, inverterStatus = 'idle') {
    const now = Date.now();
    const timestamp = Math.floor(now / 1000);
    
    // Update in-memory cache for fast access
    latestReadingsCache[plantId] = {
        timestamp,
        pv_power: pv,
        grid_power: grid,
        consumption,
        battery_soc: batterySoc,
        battery_power: batteryPower
    };
    
    statements.insertRaw.run(plantId, timestamp, pv, grid, consumption, batterySoc, batteryPower);
    
    const hourTimestamp = Math.floor(timestamp / 3600) * 3600;
    statements.upsertHourly.run(plantId, hourTimestamp, pv, pv, grid, consumption, consumption, batterySoc, batteryPower, 1);
    
    // Use local date for daily aggregation
    const date = getLocalDate(now);
    const intervalHours = 10 / 3600;
    const pvEnergy = pv * intervalHours;
    const gridImport = grid > 0 ? grid * intervalHours : 0;
    const gridExport = grid < 0 ? Math.abs(grid) * intervalHours : 0;
    const consumptionEnergy = consumption * intervalHours;
    
    // Use inverterStatus to determine battery charge/discharge direction
    // batteryPower is always positive (absolute value from dashboard)
    const batteryCharge = inverterStatus === 'charging' ? batteryPower * intervalHours : 0;
    const batteryDischarge = inverterStatus === 'discharging' ? batteryPower * intervalHours : 0;
    
    statements.upsertDaily.run(plantId, date, pvEnergy, gridImport, gridExport, consumptionEnergy, 
                               batteryCharge, batteryDischarge, pv, consumption, batterySoc, batterySoc, 1);
    
    // Check if we need to process a 15-minute peak window
    checkAndProcessPeakWindow(plantId);
}

// Clean old data
function cleanOldData() {
    const now = Math.floor(Date.now() / 1000);
    statements.deleteOldRaw.run(now - (CONFIG.retention.raw * 3600));
    statements.deleteOldHourly.run(now - (CONFIG.retention.hourly * 24 * 3600));
    
    const dailyCutoff = new Date();
    dailyCutoff.setDate(dailyCutoff.getDate() - CONFIG.retention.daily);
    statements.deleteOldDaily.run(dailyCutoff.toISOString().split('T')[0]);
    
    // Also clean expired sessions
    db.prepare(`DELETE FROM sessions WHERE expires_at < ?`).run(now);
    
    console.log(`[${new Date().toISOString()}] Cleaned old data`);
}

setInterval(cleanOldData, 3600 * 1000);

// Get history with smart resolution
function getHistory(range = 'day', date = null, plantId = 1) {
    const now = Math.floor(Date.now() / 1000);
    let data = [];
    
    if (date) {
        const startOfDay = new Date(date);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);
        
        const startTs = Math.floor(startOfDay.getTime() / 1000);
        const endTs = Math.floor(endOfDay.getTime() / 1000);
        
        const today = new Date().toISOString().split('T')[0];
        if (date === today) {
            data = statements.getRawByRange.all(plantId, startTs, now);
        } else {
            data = statements.getRawByRange.all(plantId, startTs, endTs);
            if (data.length === 0) {
                data = statements.getHourlyByRange.all(plantId, startTs, endTs);
            }
        }
        
        // Aggregate to 15-minute intervals for day view
        data = aggregateToInterval(data, 15 * 60); // 15 minutes
        
        return data.map(row => ({ ...row, timestamp: row.timestamp * 1000 }));
    }
    
    switch (range) {
        case 'hour':
            data = statements.getRawByRange.all(plantId, now - 3600, now);
            // Keep raw data for hour view (higher resolution)
            break;
        case 'day':
            const todayStart = new Date();
            todayStart.setHours(0, 0, 0, 0);
            data = statements.getRawByRange.all(plantId, Math.floor(todayStart.getTime() / 1000), now);
            // Aggregate to 15-minute intervals
            data = aggregateToInterval(data, 15 * 60);
            break;
        case 'week':
            data = statements.getHourlyByRange.all(plantId, now - (7 * 24 * 3600), now);
            // Keep hourly for week
            break;
        case 'month':
            data = statements.getHourlyByRange.all(plantId, now - (30 * 24 * 3600), now);
            // Aggregate to 4-hour intervals for month
            data = aggregateToInterval(data, 4 * 3600);
            break;
        case 'year':
            const yearAgo = new Date();
            yearAgo.setDate(yearAgo.getDate() - 365);
            const today = new Date().toISOString().split('T')[0];
            data = statements.getDailyByRange.all(plantId, yearAgo.toISOString().split('T')[0], today);
            break;
    }
    
    return data.map(row => ({
        ...row,
        timestamp: (row.timestamp || new Date(row.date).getTime() / 1000) * 1000
    }));
}

// Aggregate data to fixed time intervals (e.g., 15 minutes)
function aggregateToInterval(data, intervalSeconds) {
    if (!data || data.length === 0) return [];
    
    const buckets = new Map();
    
    for (const row of data) {
        // Round timestamp down to interval
        const bucketTs = Math.floor(row.timestamp / intervalSeconds) * intervalSeconds;
        
        if (!buckets.has(bucketTs)) {
            buckets.set(bucketTs, {
                timestamp: bucketTs,
                pv_power: [],
                grid_power: [],
                consumption: [],
                battery_soc: [],
                battery_power: []
            });
        }
        
        const bucket = buckets.get(bucketTs);
        if (row.pv_power !== null && row.pv_power !== undefined) bucket.pv_power.push(row.pv_power);
        if (row.grid_power !== null && row.grid_power !== undefined) bucket.grid_power.push(row.grid_power);
        if (row.consumption !== null && row.consumption !== undefined) bucket.consumption.push(row.consumption);
        if (row.battery_soc !== null && row.battery_soc !== undefined) bucket.battery_soc.push(row.battery_soc);
        if (row.battery_power !== null && row.battery_power !== undefined) bucket.battery_power.push(row.battery_power);
    }
    
    // Convert buckets to array with averaged values
    const result = [];
    const sortedKeys = Array.from(buckets.keys()).sort((a, b) => a - b);
    
    for (const ts of sortedKeys) {
        const bucket = buckets.get(ts);
        result.push({
            timestamp: ts,
            pv_power: bucket.pv_power.length > 0 ? bucket.pv_power.reduce((a, b) => a + b, 0) / bucket.pv_power.length : 0,
            grid_power: bucket.grid_power.length > 0 ? bucket.grid_power.reduce((a, b) => a + b, 0) / bucket.grid_power.length : 0,
            consumption: bucket.consumption.length > 0 ? bucket.consumption.reduce((a, b) => a + b, 0) / bucket.consumption.length : 0,
            battery_soc: bucket.battery_soc.length > 0 ? bucket.battery_soc.reduce((a, b) => a + b, 0) / bucket.battery_soc.length : 0,
            battery_power: bucket.battery_power.length > 0 ? bucket.battery_power.reduce((a, b) => a + b, 0) / bucket.battery_power.length : 0
        });
    }
    
    return result;
}

function downsample(data, targetPoints) {
    if (data.length <= targetPoints) return data;
    
    const result = [];
    const bucketSize = Math.floor(data.length / targetPoints);
    
    result.push(data[0]);
    
    for (let i = 1; i < targetPoints - 1; i++) {
        const start = i * bucketSize;
        const end = Math.min(start + bucketSize, data.length);
        
        let sumPv = 0, sumGrid = 0, sumCons = 0, sumBat = 0, sumTs = 0;
        for (let j = start; j < end; j++) {
            sumPv += data[j].pv_power || 0;
            sumGrid += data[j].grid_power || 0;
            sumCons += data[j].consumption || 0;
            sumBat += data[j].battery_soc || 0;
            sumTs += data[j].timestamp;
        }
        const count = end - start;
        
        result.push({
            timestamp: Math.floor(sumTs / count),
            pv_power: sumPv / count,
            grid_power: sumGrid / count,
            consumption: sumCons / count,
            battery_soc: sumBat / count
        });
    }
    
    result.push(data[data.length - 1]);
    return result;
}

function getDailySummary(days = 7, plantId = 1) {
    const endDate = new Date().toISOString().split('T')[0];
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    return statements.getDailyByRange.all(plantId, startDate.toISOString().split('T')[0], endDate);
}

// ============================================
// HTTP SERVER
// ============================================

const server = http.createServer(async (req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }
    
    const url = require('url');
    const parsedUrl = url.parse(req.url, true);
    const reqPath = parsedUrl.pathname;
    const query = parsedUrl.query;
    
    // Helper to send JSON response
    const sendJson = (status, data) => {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(data));
    };
    
    // Helper to read POST body
    const readBody = () => new Promise((resolve) => {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            console.log(`[readBody] Raw body: ${body}`);
            try { 
                const parsed = JSON.parse(body);
                console.log(`[readBody] Parsed:`, parsed);
                resolve(parsed); 
            } 
            catch (e) { 
                console.log(`[readBody] Parse failed: ${e.message}`);
                resolve({}); 
            }
        });
    });
    
    try {
        // ============================================
        // STATIC FILES (Dashboard & Home)
        // ============================================
        
        // Home page - plants overview
        if (reqPath === '/' || reqPath === '/home' || reqPath === '/home.html') {
            const homePath = path.join(__dirname, 'public', 'home.html');
            if (fs.existsSync(homePath)) {
                const html = fs.readFileSync(homePath, 'utf8');
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(html);
                return;
            } else {
                // Fallback to dashboard if home doesn't exist
                const dashboardPath = path.join(__dirname, 'public', 'index.html');
                if (fs.existsSync(dashboardPath)) {
                    const html = fs.readFileSync(dashboardPath, 'utf8');
                    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                    res.end(html);
                    return;
                }
            }
        }
        
        // Dashboard - detailed plant view
        if (reqPath === '/dashboard' || reqPath === '/index.html' || reqPath === '/solar-dashboard.html' || reqPath.startsWith('/dashboard/')) {
            const dashboardPath = path.join(__dirname, 'public', 'index.html');
            if (fs.existsSync(dashboardPath)) {
                const html = fs.readFileSync(dashboardPath, 'utf8');
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(html);
                return;
            } else {
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(`
                    <!DOCTYPE html>
                    <html>
                    <head><title>Shelly Solar Proxy</title></head>
                    <body style="font-family: system-ui; padding: 40px; background: #0a0f1a; color: #f7fafc;">
                        <h1 style="color: #fbbf24;">☀️ Shelly Solar Proxy Server v4</h1>
                        <p>Server is running with authentication!</p>
                        <p>Place dashboard HTML in <code>/public/index.html</code></p>
                    </body>
                    </html>
                `);
                return;
            }
        }

        // ============================================
        // AUTH ENDPOINTS
        // ============================================
        
        // Version check (for debugging)
        if (reqPath === '/api/version') {
            sendJson(200, { version: 'v4-multi-plant', timestamp: new Date().toISOString() });
            return;
        }
        
        // Check if any users exist (for first-time setup)
        if (reqPath === '/api/auth/status') {
            const userCount = authStatements.getUserCount.get().count;
            sendJson(200, { 
                hasUsers: userCount > 0,
                requiresSetup: userCount === 0
            });
            return;
        }
        
        // Register new user
        if (reqPath === '/api/auth/register' && req.method === 'POST') {
            const body = await readBody();
            const { email, password } = body;
            
            if (!email || !password) {
                sendJson(400, { error: 'Email and password required' });
                return;
            }
            
            if (password.length < 6) {
                sendJson(400, { error: 'Password must be at least 6 characters' });
                return;
            }
            
            // Check if email already exists
            const existingUser = authStatements.getUserByEmail.get(email.toLowerCase());
            if (existingUser) {
                sendJson(400, { error: 'Email already registered' });
                return;
            }
            
            // Create user
            const { hash, salt } = hashPassword(password);
            const defaultConfig = JSON.stringify({
                shellyIp: '',
                pvComponentId: '200',
                gridComponentId: '204',
                consumptionComponentId: '205',
                batterySOCComponentId: '203',
                batteryPowerComponentId: '202',
                inverterStatusComponentId: '200'
            });
            
            try {
                const result = authStatements.createUser.run(email.toLowerCase(), hash, salt, defaultConfig);
                const session = createSession(result.lastInsertRowid);
                
                sendJson(200, { 
                    success: true, 
                    token: session.token,
                    expiresAt: session.expiresAt,
                    email: email.toLowerCase()
                });
            } catch (e) {
                sendJson(500, { error: 'Failed to create user' });
            }
            return;
        }
        
        // Login
        if (reqPath === '/api/auth/login' && req.method === 'POST') {
            const body = await readBody();
            const { email, password } = body;
            
            if (!email || !password) {
                sendJson(400, { error: 'Email and password required' });
                return;
            }
            
            const user = authStatements.getUserByEmail.get(email.toLowerCase());
            if (!user) {
                sendJson(401, { error: 'Invalid email or password' });
                return;
            }
            
            const { hash } = hashPassword(password, user.salt);
            if (hash !== user.password_hash) {
                sendJson(401, { error: 'Invalid email or password' });
                return;
            }
            
            const session = createSession(user.id);
            sendJson(200, { 
                success: true, 
                token: session.token,
                expiresAt: session.expiresAt,
                email: user.email,
                config: JSON.parse(user.config || '{}')
            });
            return;
        }
        
        // Logout
        if (reqPath === '/api/auth/logout' && req.method === 'POST') {
            const user = getUserFromRequest(req);
            if (user) {
                authStatements.deleteSession.run(user.token);
            }
            sendJson(200, { success: true });
            return;
        }
        
        // Change password
        if (reqPath === '/api/auth/change-password' && req.method === 'POST') {
            const user = getUserFromRequest(req);
            if (!user) {
                sendJson(401, { error: 'Not authenticated' });
                return;
            }
            
            const body = await readBody();
            const { currentPassword, newPassword } = body;
            
            if (!currentPassword || !newPassword) {
                sendJson(400, { error: 'Current and new passwords required' });
                return;
            }
            
            if (newPassword.length < 6) {
                sendJson(400, { error: 'New password must be at least 6 characters' });
                return;
            }
            
            // Get full user record to verify current password
            const fullUser = authStatements.getUserByEmail.get(user.email);
            if (!fullUser) {
                sendJson(404, { error: 'User not found' });
                return;
            }
            
            // Verify current password
            const currentHash = crypto.pbkdf2Sync(currentPassword, fullUser.salt, 10000, 64, 'sha512').toString('hex');
            if (currentHash !== fullUser.password_hash) {
                sendJson(401, { error: 'Current password is incorrect' });
                return;
            }
            
            // Generate new salt and hash
            const newSalt = crypto.randomBytes(32).toString('hex');
            const newHash = crypto.pbkdf2Sync(newPassword, newSalt, 10000, 64, 'sha512').toString('hex');
            
            // Update password
            db.prepare('UPDATE users SET password_hash = ?, salt = ?, updated_at = strftime(\'%s\', \'now\') WHERE id = ?')
                .run(newHash, newSalt, fullUser.id);
            
            // Invalidate all existing sessions for this user (security)
            db.prepare('DELETE FROM sessions WHERE user_id = ?').run(fullUser.id);
            
            console.log(`Password changed for user: ${user.email}`);
            sendJson(200, { success: true, message: 'Password changed. Please login again.' });
            return;
        }
        
        // Verify token / Get current user
        if (reqPath === '/api/auth/me') {
            const user = getUserFromRequest(req);
            if (!user) {
                sendJson(401, { error: 'Not authenticated' });
                return;
            }
            
            const response = { 
                user: {
                    email: user.email,
                    config: JSON.parse(user.config || '{}')
                }
            };
            
            // Include plants data if requested (for faster home page loading)
            if (query.include === 'plants') {
                const plants = statements.getPlantsByUser.all(user.user_id);
                const today = getLocalDate();
                
                let totalPvPower = 0, totalConsumption = 0, totalGridPower = 0;
                let totalProduction = 0, totalDayConsumption = 0;
                
                const plantsOverview = plants.map(plant => {
                    let latest = latestReadingsCache[plant.id];
                    if (!latest) {
                        latest = statements.getLatestReading.get(plant.id);
                    }
                    const todaySummary = statements.getTodaySummary.get(plant.id, today);
                    
                    if (latest) {
                        totalPvPower += latest.pv_power || 0;
                        totalConsumption += latest.consumption || 0;
                        totalGridPower += latest.grid_power || 0;
                    }
                    
                    if (todaySummary) {
                        totalProduction += todaySummary.pv_energy_wh || 0;
                        totalDayConsumption += todaySummary.consumption_wh || 0;
                    }
                    
                    return {
                        id: plant.id,
                        name: plant.name,
                        location: plant.location,
                        capacity_kwp: plant.capacity_kwp,
                        config: JSON.parse(plant.config || '{}'),
                        live: latest ? {
                            pv_power: latest.pv_power || 0,
                            grid_power: latest.grid_power || 0,
                            consumption: latest.consumption || 0,
                            battery_soc: latest.battery_soc || 0,
                            updated: latest.timestamp
                        } : null,
                        today: todaySummary ? {
                            production: (todaySummary.pv_energy_wh || 0) / 1000,
                            consumption: (todaySummary.consumption_wh || 0) / 1000
                        } : { production: 0, consumption: 0 }
                    };
                });
                
                response.plants = {
                    totals: {
                        live: { pv_power: totalPvPower, consumption: totalConsumption, grid_power: totalGridPower },
                        today: { production: totalProduction / 1000, consumption: totalDayConsumption / 1000 }
                    },
                    plants: plantsOverview
                };
            }
            
            sendJson(200, response);
            return;
        }

        // ============================================
        // USER CONFIG (requires auth) - DEPRECATED, use plant config instead
        // ============================================
        
        if (reqPath === '/api/config') {
            const user = getUserFromRequest(req);
            
            if (req.method === 'GET') {
                if (!user) {
                    sendJson(401, { error: 'Not authenticated' });
                    return;
                }
                sendJson(200, JSON.parse(user.config || '{}'));
                return;
            }
            
            if (req.method === 'POST') {
                if (!user) {
                    sendJson(401, { error: 'Not authenticated' });
                    return;
                }
                
                const body = await readBody();
                authStatements.updateUserConfig.run(JSON.stringify(body), user.user_id);
                sendJson(200, { success: true });
                return;
            }
        }
        
        // PLANT-SPECIFIC CONFIG (for Shelly devices, sources, etc.)
        // ============================================
        
        if (reqPath.match(/^\/api\/plants\/\d+\/config$/) && (req.method === 'GET' || req.method === 'POST')) {
            const user = getUserFromRequest(req);
            if (!user) {
                sendJson(401, { error: 'Not authenticated' });
                return;
            }
            
            const plantId = parseInt(reqPath.split('/')[3]);
            const plant = statements.getPlantById.get(plantId);
            
            if (!plant) {
                sendJson(404, { error: 'Plant not found' });
                return;
            }
            
            if (plant.user_id !== user.user_id) {
                sendJson(403, { error: 'Access denied' });
                return;
            }
            
            if (req.method === 'GET') {
                sendJson(200, JSON.parse(plant.config || '{}'));
                return;
            }
            
            if (req.method === 'POST') {
                const body = await readBody();
                const existingConfig = JSON.parse(plant.config || '{}');
                // Merge new config with existing (preserve coordinates)
                const newConfig = { ...existingConfig, ...body };
                
                db.prepare('UPDATE plants SET config = ? WHERE id = ?').run(JSON.stringify(newConfig), plantId);
                sendJson(200, { success: true });
                return;
            }
        }

        // ============================================
        // PUBLIC ENDPOINTS (no auth required)
        // ============================================
        
        // Health check
        if (reqPath === '/health') {
            const stats = db.prepare('SELECT COUNT(*) as raw_count FROM readings_raw').get();
            const hourlyStats = db.prepare('SELECT COUNT(*) as hourly_count FROM readings_hourly').get();
            const dailyStats = db.prepare('SELECT COUNT(*) as daily_count FROM readings_daily').get();
            const userCount = authStatements.getUserCount.get().count;
            
            sendJson(200, {
                status: 'ok',
                timestamp: new Date().toISOString(),
                users: userCount,
                database: {
                    raw_readings: stats.raw_count,
                    hourly_readings: hourlyStats.hourly_count,
                    daily_readings: dailyStats.daily_count
                }
            });
            return;
        }
        
        // Shelly proxy
        if (reqPath === '/api/shelly') {
            await handleShellyProxy(req, res, query);
            return;
        }
        
        // Batch request
        if (reqPath === '/api/batch') {
            await handleBatchRequest(req, res);
            return;
        }
        
        // Debug endpoint - fetch and show raw cloud/device status
        if (reqPath === '/api/debug-status') {
            const body = await readBody();
            const connectionMode = body.connectionMode || 'direct';
            
            try {
                let status = null;
                
                if (connectionMode === 'cloud') {
                    if (!body.cloudServer || !body.cloudDeviceId || !body.cloudAuthKey) {
                        sendJson(400, { error: 'Missing cloud credentials' });
                        return;
                    }
                    status = await callShellyCloud(body.cloudServer, body.cloudDeviceId, body.cloudAuthKey);
                } else {
                    if (!body.ip) {
                        sendJson(400, { error: 'Missing device IP' });
                        return;
                    }
                    status = await callShellyRpc(body.ip, 'Shelly.GetStatus', {}, body.auth);
                }
                
                sendJson(200, {
                    mode: connectionMode,
                    keys: Object.keys(status || {}),
                    status
                });
            } catch (e) {
                sendJson(500, { error: e.message });
            }
            return;
        }
        
        // Store reading from frontend (for WS-based data)
        if (reqPath === '/api/store-reading') {
            if (req.method !== 'POST') {
                sendJson(405, { error: 'Use POST' });
                return;
            }
            
            const body = await readBody();
            const pv = body.pv ?? 0;
            const grid = body.grid ?? 0;
            const consumption = body.consumption ?? 0;
            const batterySoc = body.batterySoc ?? 0;
            const batteryPower = body.batteryPower ?? 0;
            const inverterStatus = body.inverterStatus || 'idle';
            const plantId = body.plant_id || 1;
            
            if (pv !== 0 || grid !== 0 || consumption !== 0) {
                storeReading(pv, grid, consumption, batterySoc, batteryPower, plantId, inverterStatus);
                sendJson(200, { stored: true });
            } else {
                sendJson(200, { stored: false, reason: 'All values zero' });
            }
            return;
        }
        
        // Daily stats
        if (reqPath === '/api/daily-stats') {
            const start = query.start;
            const end = query.end;
            const date = query.date || new Date().toISOString().split('T')[0];
            const plantId = parseInt(query.plant_id) || 1;
            
            // If start and end are provided, aggregate data for range
            if (start && end) {
                // First try readings_daily table
                let rangeStats = db.prepare(`
                    SELECT 
                        SUM(pv_energy_wh) as pv_energy_wh,
                        SUM(consumption_wh) as consumption_wh,
                        SUM(grid_import_wh) as grid_import_wh,
                        SUM(grid_export_wh) as grid_export_wh,
                        SUM(COALESCE(battery_charge_wh, 0)) as battery_charge_wh,
                        SUM(COALESCE(battery_discharge_wh, 0)) as battery_discharge_wh,
                        MAX(pv_power_max) as pv_power_max,
                        MAX(consumption_max) as consumption_max,
                        MIN(battery_soc_min) as battery_soc_min,
                        MAX(battery_soc_max) as battery_soc_max,
                        SUM(sample_count) as sample_count
                    FROM readings_daily 
                    WHERE plant_id = ? AND date >= ? AND date <= ?
                `).get(plantId, start, end);
                
                // If no data in daily table, try raw data
                if (!rangeStats || !rangeStats.sample_count || rangeStats.sample_count === 0) {
                    const startParts = start.split('-');
                    const endParts = end.split('-');
                    const startTs = Math.floor(new Date(parseInt(startParts[0]), parseInt(startParts[1]) - 1, parseInt(startParts[2]), 0, 0, 0).getTime() / 1000);
                    const endTs = Math.floor(new Date(parseInt(endParts[0]), parseInt(endParts[1]) - 1, parseInt(endParts[2]), 23, 59, 59).getTime() / 1000);
                    
                    rangeStats = db.prepare(`
                        SELECT 
                            SUM(pv_power) * 10 / 3600 as pv_energy_wh,
                            SUM(consumption) * 10 / 3600 as consumption_wh,
                            SUM(CASE WHEN grid_power > 0 THEN grid_power ELSE 0 END) * 10 / 3600 as grid_import_wh,
                            SUM(CASE WHEN grid_power < 0 THEN ABS(grid_power) ELSE 0 END) * 10 / 3600 as grid_export_wh,
                            SUM(CASE WHEN battery_power < 0 THEN ABS(battery_power) ELSE 0 END) * 10 / 3600 as battery_charge_wh,
                            SUM(CASE WHEN battery_power > 0 THEN battery_power ELSE 0 END) * 10 / 3600 as battery_discharge_wh,
                            MAX(pv_power) as pv_power_max,
                            MAX(consumption) as consumption_max,
                            MIN(battery_soc) as battery_soc_min,
                            MAX(battery_soc) as battery_soc_max,
                            COUNT(*) as sample_count
                        FROM readings_raw 
                        WHERE plant_id = ? AND timestamp >= ? AND timestamp <= ?
                    `).get(plantId, startTs, endTs);
                }
                
                sendJson(200, {
                    start,
                    end,
                    pv_energy_wh: rangeStats?.pv_energy_wh || 0,
                    consumption_wh: rangeStats?.consumption_wh || 0,
                    grid_import_wh: rangeStats?.grid_import_wh || 0,
                    grid_export_wh: rangeStats?.grid_export_wh || 0,
                    battery_charge_wh: rangeStats?.battery_charge_wh || 0,
                    battery_discharge_wh: rangeStats?.battery_discharge_wh || 0,
                    pv_power_max: rangeStats?.pv_power_max || 0,
                    consumption_max: rangeStats?.consumption_max || 0,
                    battery_soc_min: rangeStats?.battery_soc_min || 0,
                    battery_soc_max: rangeStats?.battery_soc_max || 0,
                    sample_count: rangeStats?.sample_count || 0
                });
                return;
            }
            
            let dailyData = db.prepare(`SELECT * FROM readings_daily WHERE plant_id = ? AND date = ?`).get(plantId, date);
            
            if (!dailyData || !dailyData.pv_energy_wh) {
                const dateParts = date.split('-');
                const startOfDay = new Date(parseInt(dateParts[0]), parseInt(dateParts[1]) - 1, parseInt(dateParts[2]), 0, 0, 0);
                const endOfDay = new Date(parseInt(dateParts[0]), parseInt(dateParts[1]) - 1, parseInt(dateParts[2]), 23, 59, 59);
                
                const startTs = Math.floor(startOfDay.getTime() / 1000);
                const endTs = Math.floor(endOfDay.getTime() / 1000);
                
                const rawStats = db.prepare(`
                    SELECT 
                        SUM(pv_power) * 10 / 3600 as pv_energy_wh,
                        SUM(consumption) * 10 / 3600 as consumption_wh,
                        SUM(CASE WHEN grid_power > 0 THEN grid_power ELSE 0 END) * 10 / 3600 as grid_import_wh,
                        SUM(CASE WHEN grid_power < 0 THEN ABS(grid_power) ELSE 0 END) * 10 / 3600 as grid_export_wh,
                        SUM(CASE WHEN battery_power < 0 THEN ABS(battery_power) ELSE 0 END) * 10 / 3600 as battery_charge_wh,
                        SUM(CASE WHEN battery_power > 0 THEN battery_power ELSE 0 END) * 10 / 3600 as battery_discharge_wh,
                        MAX(pv_power) as pv_power_max,
                        MAX(consumption) as consumption_max,
                        MIN(battery_soc) as battery_soc_min,
                        MAX(battery_soc) as battery_soc_max,
                        COUNT(*) as sample_count
                    FROM readings_raw 
                    WHERE plant_id = ? AND timestamp >= ? AND timestamp <= ?
                `).get(plantId, startTs, endTs);
                
                if (rawStats && rawStats.sample_count > 0) {
                    dailyData = rawStats;
                }
            }
            
            const prevDate = new Date(date);
            prevDate.setDate(prevDate.getDate() - 1);
            const prevData = db.prepare(`SELECT * FROM readings_daily WHERE plant_id = ? AND date = ?`).get(plantId, prevDate.toISOString().split('T')[0]);
            
            sendJson(200, {
                date,
                current: dailyData || {
                    pv_energy_wh: 0, consumption_wh: 0, grid_import_wh: 0, grid_export_wh: 0,
                    battery_charge_wh: 0, battery_discharge_wh: 0, pv_power_max: 0, consumption_max: 0
                },
                previous: prevData || null
            });
            return;
        }
        
        // History
        if (reqPath === '/api/history' && req.method === 'GET') {
            const range = query.range || 'day';
            const date = query.date || null;
            const plantId = parseInt(query.plant_id) || 1;
            const data = getHistory(range, date, plantId);
            
            sendJson(200, { range, date: date || 'current', count: data.length, data });
            return;
        }
        
        // Daily summary
        if (reqPath === '/api/daily') {
            const plantId = parseInt(query.plant_id) || 1;
            let data;
            
            if (query.start && query.end) {
                // Date range query
                data = statements.getDailyByRange.all(plantId, query.start, query.end);
            } else {
                // Legacy: days parameter
                const days = parseInt(query.days) || 7;
                data = getDailySummary(days, plantId);
            }
            
            const formatted = data.map(row => ({
                date: row.date,
                dayName: new Date(row.date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short' }),
                production: row.pv_energy_wh || 0,
                consumption: row.consumption_wh || 0,
                gridImport: row.grid_import_wh || 0,
                gridExport: row.grid_export_wh || 0,
                batteryCharge: row.battery_charge_wh || 0,
                batteryDischarge: row.battery_discharge_wh || 0
            }));
            
            sendJson(200, { data: formatted });
            return;
        }
        
        // Store reading manually
        if (reqPath === '/api/store' && req.method === 'POST') {
            const body = await readBody();
            const plantId = body.plant_id || 1;
            const inverterStatus = body.inverterStatus || 'idle';
            storeReading(body.pv || 0, body.grid || 0, body.consumption || 0, body.battery || 0, body.batteryPower || 0, plantId, inverterStatus);
            sendJson(200, { success: true });
            return;
        }
        
        // Live update - cache only, no database write (for fast home page updates)
        if (reqPath === '/api/live-update' && req.method === 'POST') {
            const body = await readBody();
            const plantId = body.plant_id || 1;
            
            // Update cache only - no database write
            latestReadingsCache[plantId] = {
                timestamp: Math.floor(Date.now() / 1000),
                pv_power: body.pv || 0,
                grid_power: body.grid || 0,
                consumption: body.consumption || 0,
                battery_soc: body.battery || 0,
                battery_power: body.batteryPower || 0
            };
            
            sendJson(200, { success: true });
            return;
        }
        
        // Database stats
        if (reqPath === '/api/stats') {
            const rawCount = db.prepare('SELECT COUNT(*) as c FROM readings_raw').get().c;
            const hourlyCount = db.prepare('SELECT COUNT(*) as c FROM readings_hourly').get().c;
            const dailyCount = db.prepare('SELECT COUNT(*) as c FROM readings_daily').get().c;
            const dbSize = fs.statSync(CONFIG.dbPath).size;
            
            sendJson(200, {
                readings: { raw: rawCount, hourly: hourlyCount, daily: dailyCount },
                database_size_mb: (dbSize / 1024 / 1024).toFixed(2),
                retention: CONFIG.retention
            });
            return;
        }
        
        // Debug endpoint for peaks
        if (reqPath === '/api/peaks-debug') {
            const today = new Date().toISOString().split('T')[0];
            const allPeaks = db.prepare('SELECT * FROM daily_peaks').all();
            const rawCount = db.prepare('SELECT COUNT(*) as c FROM readings_raw').get().c;
            const todayRaw = db.prepare('SELECT COUNT(*) as c FROM readings_raw WHERE timestamp > ?').get(
                Math.floor(new Date(today).getTime() / 1000)
            ).c;
            
            sendJson(200, {
                today,
                rawReadingsTotal: rawCount,
                rawReadingsToday: todayRaw,
                peaksTable: allPeaks,
                lastProcessedWindow,
                lastProcessedWindowISO: new Date(lastProcessedWindow * 1000).toISOString()
            });
            return;
        }
        
        // Force reprocess peaks for today
        if (reqPath === '/api/peaks-reprocess') {
            try {
                // Reset lastProcessedWindow to start of day
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                lastProcessedWindow = Math.floor(today.getTime() / 1000);
                
                // Delete today's peak record to allow fresh calculation
                const todayStr = new Date().toISOString().split('T')[0];
                db.prepare('DELETE FROM daily_peaks WHERE date = ?').run(todayStr);
                
                // Reprocess
                processStartupPeaks();
                
                const peakData = db.prepare('SELECT * FROM daily_peaks WHERE date = ?').get(todayStr);
                
                sendJson(200, {
                    success: true,
                    message: 'Peaks reprocessed for today',
                    lastProcessedWindow,
                    lastProcessedWindowISO: new Date(lastProcessedWindow * 1000).toISOString(),
                    todayPeak: peakData
                });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Get timezone (GET)
        if (reqPath === '/api/timezone' && req.method === 'GET') {
            console.log(`[API] GET /api/timezone - returning: ${CONFIG.timezone}`);
            sendJson(200, { 
                timezone: CONFIG.timezone,
                localTime: getLocalDatetime(),
                utcOffset: getTimezoneOffset()
            });
            return;
        }
        
        // Debug endpoint to check settings status
        if (reqPath === '/api/debug/settings') {
            const dataDir = path.dirname(CONFIG.settingsPath);
            let files = [];
            let fileContent = null;
            
            if (fs.existsSync(dataDir)) {
                files = fs.readdirSync(dataDir);
            }
            if (fs.existsSync(CONFIG.settingsPath)) {
                fileContent = fs.readFileSync(CONFIG.settingsPath, 'utf8');
            }
            
            sendJson(200, {
                settingsPath: CONFIG.settingsPath,
                dataDir: dataDir,
                dataDirExists: fs.existsSync(dataDir),
                settingsFileExists: fs.existsSync(CONFIG.settingsPath),
                filesInDataDir: files,
                fileContent: fileContent,
                currentTimezone: CONFIG.timezone
            });
            return;
        }
        
        // Set timezone (POST)
        if (reqPath === '/api/timezone' && req.method === 'POST') {
            console.log(`[API] POST /api/timezone - current: ${CONFIG.timezone}`);
            try {
                const body = await readBody();
                console.log(`[API] POST /api/timezone - body:`, body);
                const newTimezone = body.timezone;
                
                if (!newTimezone) {
                    sendJson(400, { error: 'Timezone is required' });
                    return;
                }
                
                // Validate timezone by trying to use it
                try {
                    new Intl.DateTimeFormat('en-US', { timeZone: newTimezone }).format(new Date());
                } catch (e) {
                    sendJson(400, { error: 'Invalid timezone. Use IANA format like "Europe/Sofia" or "America/New_York"' });
                    return;
                }
                
                console.log(`[API] POST /api/timezone - setting to: ${newTimezone}`);
                CONFIG.timezone = newTimezone;
                saveSettings();
                console.log(`[API] POST /api/timezone - CONFIG.timezone is now: ${CONFIG.timezone}`);
                
                // Reprocess today's peaks with new timezone
                const todayStr = getLocalDate();
                db.prepare('DELETE FROM daily_peaks WHERE date = ?').run(todayStr);
                processStartupPeaks();
                
                sendJson(200, { 
                    success: true,
                    timezone: CONFIG.timezone,
                    localTime: getLocalDatetime(),
                    message: 'Timezone updated and peaks reprocessed'
                });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // ============================================
        // PLANT MANAGEMENT API
        // ============================================
        
        // Get authenticated user for plant operations
        const authUser = getUserFromRequest(req);
        
        // Get all plants for current user
        if (reqPath === '/api/plants' && req.method === 'GET') {
            if (!authUser) {
                sendJson(401, { error: 'Authentication required' });
                return;
            }
            
            try {
                const plants = statements.getPlantsByUser.all(authUser.user_id);
                
                // Add live data and today summary for each plant
                const today = getLocalDate();
                const plantsWithData = plants.map(plant => {
                    const latest = statements.getLatestReading.get(plant.id);
                    const todaySummary = statements.getTodaySummary.get(plant.id, today);
                    
                    return {
                        ...plant,
                        config: JSON.parse(plant.config || '{}'),
                        live: latest ? {
                            timestamp: latest.timestamp,
                            pv_power: latest.pv_power || 0,
                            grid_power: latest.grid_power || 0,
                            consumption: latest.consumption || 0,
                            battery_soc: latest.battery_soc || 0,
                            battery_power: latest.battery_power || 0
                        } : null,
                        today: todaySummary ? {
                            production: (todaySummary.pv_energy_wh || 0) / 1000,
                            consumption: (todaySummary.consumption_wh || 0) / 1000,
                            grid_import: (todaySummary.grid_import_wh || 0) / 1000,
                            grid_export: (todaySummary.grid_export_wh || 0) / 1000,
                            battery_charge: (todaySummary.battery_charge_wh || 0) / 1000,
                            battery_discharge: (todaySummary.battery_discharge_wh || 0) / 1000
                        } : null
                    };
                });
                
                sendJson(200, { plants: plantsWithData });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Create new plant
        if (reqPath === '/api/plants' && req.method === 'POST') {
            if (!authUser) {
                sendJson(401, { error: 'Authentication required' });
                return;
            }
            
            try {
                const body = await readBody();
                const { name, location, capacity_kwp, config, latitude, longitude } = body;
                
                if (!name) {
                    sendJson(400, { error: 'Plant name is required' });
                    return;
                }
                
                // Build config with coordinates
                const plantConfig = { ...(config || {}), latitude, longitude };
                
                const result = statements.createPlant.run(
                    authUser.user_id, 
                    name, 
                    location || '', 
                    capacity_kwp || 0,
                    JSON.stringify(plantConfig)
                );
                
                const plant = statements.getPlantById.get(result.lastInsertRowid);
                
                // Initialize peak tracking for new plant
                lastProcessedWindows[plant.id] = getStartOfLocalDay();
                
                sendJson(201, { 
                    success: true, 
                    plant: { ...plant, config: JSON.parse(plant.config || '{}') }
                });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Get single plant
        if (reqPath.match(/^\/api\/plants\/\d+$/) && req.method === 'GET') {
            const plantId = parseInt(reqPath.split('/')[3]);
            
            try {
                const plant = statements.getPlantById.get(plantId);
                if (!plant) {
                    sendJson(404, { error: 'Plant not found' });
                    return;
                }
                
                // Check ownership if authenticated
                if (authUser && plant.user_id !== authUser.user_id) {
                    sendJson(403, { error: 'Access denied' });
                    return;
                }
                
                const today = getLocalDate();
                const latest = statements.getLatestReading.get(plantId);
                const todaySummary = statements.getTodaySummary.get(plantId, today);
                
                sendJson(200, {
                    plant: {
                        ...plant,
                        config: JSON.parse(plant.config || '{}'),
                        live: latest ? {
                            timestamp: latest.timestamp,
                            pv_power: latest.pv_power || 0,
                            grid_power: latest.grid_power || 0,
                            consumption: latest.consumption || 0,
                            battery_soc: latest.battery_soc || 0,
                            battery_power: latest.battery_power || 0
                        } : null,
                        today: todaySummary ? {
                            production: (todaySummary.pv_energy_wh || 0) / 1000,
                            consumption: (todaySummary.consumption_wh || 0) / 1000,
                            grid_import: (todaySummary.grid_import_wh || 0) / 1000,
                            grid_export: (todaySummary.grid_export_wh || 0) / 1000
                        } : null
                    }
                });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Update plant
        if (reqPath.match(/^\/api\/plants\/\d+$/) && req.method === 'PUT') {
            if (!authUser) {
                sendJson(401, { error: 'Authentication required' });
                return;
            }
            
            const plantId = parseInt(reqPath.split('/')[3]);
            
            try {
                const body = await readBody();
                const { name, location, capacity_kwp, config, latitude, longitude } = body;
                
                // Get existing plant to preserve other config values
                const existingPlant = statements.getPlantById.get(plantId);
                if (!existingPlant) {
                    sendJson(404, { error: 'Plant not found' });
                    return;
                }
                
                // Merge config with coordinates
                const existingConfig = JSON.parse(existingPlant.config || '{}');
                const newConfig = { 
                    ...existingConfig, 
                    ...(config || {}),
                    latitude: latitude !== undefined ? latitude : existingConfig.latitude,
                    longitude: longitude !== undefined ? longitude : existingConfig.longitude
                };
                
                const result = statements.updatePlant.run(
                    name,
                    location || '',
                    capacity_kwp || 0,
                    JSON.stringify(newConfig),
                    plantId,
                    authUser.user_id
                );
                
                if (result.changes === 0) {
                    sendJson(404, { error: 'Plant not found or access denied' });
                    return;
                }
                
                const plant = statements.getPlantById.get(plantId);
                sendJson(200, { 
                    success: true, 
                    plant: { ...plant, config: JSON.parse(plant.config || '{}') }
                });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Delete plant
        if (reqPath.match(/^\/api\/plants\/\d+$/) && req.method === 'DELETE') {
            if (!authUser) {
                sendJson(401, { error: 'Authentication required' });
                return;
            }
            
            const plantId = parseInt(reqPath.split('/')[3]);
            
            try {
                const result = statements.deletePlant.run(plantId, authUser.user_id);
                
                if (result.changes === 0) {
                    sendJson(404, { error: 'Plant not found or access denied' });
                    return;
                }
                
                // Clean up data for deleted plant
                db.prepare('DELETE FROM readings_raw WHERE plant_id = ?').run(plantId);
                db.prepare('DELETE FROM readings_hourly WHERE plant_id = ?').run(plantId);
                db.prepare('DELETE FROM readings_daily WHERE plant_id = ?').run(plantId);
                db.prepare('DELETE FROM daily_peaks WHERE plant_id = ?').run(plantId);
                
                delete lastProcessedWindows[plantId];
                delete latestReadingsCache[plantId];
                
                sendJson(200, { success: true, message: 'Plant deleted' });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Get plants overview (for home page - public summary)
        if (reqPath === '/api/plants/overview') {
            if (!authUser) {
                sendJson(401, { error: 'Authentication required' });
                return;
            }
            
            try {
                const plants = statements.getPlantsByUser.all(authUser.user_id);
                const today = getLocalDate();
                
                let totalPvPower = 0, totalConsumption = 0, totalGridPower = 0;
                let totalProduction = 0, totalDayConsumption = 0;
                
                const plantsOverview = plants.map(plant => {
                    // Use in-memory cache first for instant data, fall back to database
                    let latest = latestReadingsCache[plant.id];
                    if (!latest) {
                        latest = statements.getLatestReading.get(plant.id);
                    }
                    const todaySummary = statements.getTodaySummary.get(plant.id, today);
                    
                    if (latest) {
                        totalPvPower += latest.pv_power || 0;
                        totalConsumption += latest.consumption || 0;
                        totalGridPower += latest.grid_power || 0;
                    }
                    
                    if (todaySummary) {
                        totalProduction += todaySummary.pv_energy_wh || 0;
                        totalDayConsumption += todaySummary.consumption_wh || 0;
                    }
                    
                    return {
                        id: plant.id,
                        name: plant.name,
                        location: plant.location,
                        capacity_kwp: plant.capacity_kwp,
                        config: JSON.parse(plant.config || '{}'),
                        live: latest ? {
                            pv_power: latest.pv_power || 0,
                            grid_power: latest.grid_power || 0,
                            consumption: latest.consumption || 0,
                            battery_soc: latest.battery_soc || 0,
                            updated: latest.timestamp
                        } : null,
                        today: todaySummary ? {
                            production: (todaySummary.pv_energy_wh || 0) / 1000,
                            consumption: (todaySummary.consumption_wh || 0) / 1000
                        } : { production: 0, consumption: 0 }
                    };
                });
                
                sendJson(200, {
                    totals: {
                        live: {
                            pv_power: totalPvPower,
                            consumption: totalConsumption,
                            grid_power: totalGridPower
                        },
                        today: {
                            production: totalProduction / 1000,
                            consumption: totalDayConsumption / 1000
                        }
                    },
                    plants: plantsOverview
                });
            } catch (error) {
                sendJson(500, { error: error.message });
            }
            return;
        }
        
        // Peaks API - 15-minute averages
        if (reqPath === '/api/peaks') {
            const plantId = parseInt(query.plant_id) || 1;
            const period = query.period || 'day'; // day, month, year, total
            const dateStr = query.date || new Date().toISOString().split('T')[0];
            
            let startDate, endDate;
            const queryDate = new Date(dateStr);
            
            if (period === 'day') {
                startDate = dateStr;
                endDate = dateStr;
            } else if (period === 'month') {
                startDate = new Date(queryDate.getFullYear(), queryDate.getMonth(), 1).toISOString().split('T')[0];
                endDate = new Date(queryDate.getFullYear(), queryDate.getMonth() + 1, 0).toISOString().split('T')[0];
            } else if (period === 'year') {
                startDate = `${queryDate.getFullYear()}-01-01`;
                endDate = `${queryDate.getFullYear()}-12-31`;
            } else {
                // total - last 365 days
                const end = new Date();
                const start = new Date();
                start.setDate(start.getDate() - 365);
                startDate = start.toISOString().split('T')[0];
                endDate = end.toISOString().split('T')[0];
            }
            
            const peaksData = statements.getPeaksByDateRange.all(plantId, startDate, endDate);
            
            // Find max peaks across the period
            let maxPv = { power: 0, time: null, date: null };
            let maxGrid = { power: 0, time: null, date: null };
            let maxCons = { power: 0, time: null, date: null };
            
            peaksData.forEach(row => {
                if ((row.peak_pv_power || 0) > maxPv.power) {
                    maxPv = { power: row.peak_pv_power, time: row.peak_pv_time, date: row.date };
                }
                if ((row.peak_grid_power || 0) > maxGrid.power) {
                    maxGrid = { power: row.peak_grid_power, time: row.peak_grid_time, date: row.date };
                }
                if ((row.peak_consumption_power || 0) > maxCons.power) {
                    maxCons = { power: row.peak_consumption_power, time: row.peak_consumption_time, date: row.date };
                }
            });
            
            sendJson(200, {
                period,
                startDate,
                endDate,
                daysWithData: peaksData.length,
                peaks: {
                    pv: {
                        power: maxPv.power,
                        time: maxPv.time,
                        date: maxPv.date
                    },
                    grid: {
                        power: maxGrid.power,
                        time: maxGrid.time,
                        date: maxGrid.date
                    },
                    consumption: {
                        power: maxCons.power,
                        time: maxCons.time,
                        date: maxCons.date
                    }
                }
            });
            return;
        }
        
        // 404
        sendJson(404, { error: 'Not found' });
        
    } catch (error) {
        console.error('Request error:', error);
        sendJson(500, { error: error.message });
    }
});

// Shelly proxy handler
async function handleShellyProxy(req, res, query) {
    const deviceIp = query.ip || CONFIG.defaultDevice;
    if (!deviceIp) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing device IP' }));
        return;
    }
    
    const method = query.method;
    if (!method) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing method' }));
        return;
    }
    
    const params = {};
    for (const [key, value] of Object.entries(query)) {
        if (!['ip', 'method', 'auth'].includes(key)) {
            params[key] = isNaN(value) ? value : Number(value);
        }
    }
    
    try {
        const result = await callShellyRpc(deviceIp, method, params, query.auth);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
    } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: error.message }));
    }
}

// Batch handler - supports per-call device configuration
async function handleBatchRequest(req, res) {
    if (req.method !== 'POST') {
        res.writeHead(405, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Use POST' }));
        return;
    }
    
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
        try {
            const requests = JSON.parse(body);
            const cloudServer = requests.cloudServer;
            const cloudAuthKey = requests.cloudAuthKey;
            
            // Cache for device statuses (to avoid fetching same device multiple times)
            const deviceStatusCache = {};
            
            const calls = requests.calls || [];
            const results = await Promise.all(
                calls.map(async (call) => {
                    try {
                        const connType = call.connType || 'direct';
                        const device = call.device;
                        
                        if (!device) {
                            return { key: call.key, success: false, error: 'No device specified' };
                        }
                        
                        // Get device status (cached)
                        const cacheKey = `${connType}:${device}`;
                        let deviceStatus = deviceStatusCache[cacheKey];
                        
                        if (!deviceStatus) {
                            if (connType === 'cloud') {
                                if (!cloudServer || !cloudAuthKey) {
                                    return { key: call.key, success: false, error: 'Missing cloud credentials' };
                                }
                                try {
                                    deviceStatus = await callShellyCloud(cloudServer, device, cloudAuthKey);
                                    if (deviceStatus.device_status) {
                                        deviceStatus = deviceStatus.device_status;
                                    }
                                    console.log(`Cloud fetch for ${device}: ${Object.keys(deviceStatus).length} keys`);
                                } catch (e) {
                                    return { key: call.key, success: false, error: `Cloud error: ${e.message}` };
                                }
                            } else {
                                // Direct mode - only fetch full status if needed for path lookup
                                if (call.path) {
                                    try {
                                        deviceStatus = await callShellyRpc(device, 'Shelly.GetStatus', {});
                                    } catch (e) {
                                        return { key: call.key, success: false, error: `Device error: ${e.message}` };
                                    }
                                }
                            }
                            deviceStatusCache[cacheKey] = deviceStatus;
                        }
                        
                        // Path-based lookup
                        if (call.path && deviceStatus) {
                            const value = getValueByPath(deviceStatus, call.path);
                            return { key: call.key, success: true, data: { value } };
                        }
                        
                        // Cloud mode - lookup from device status
                        if (connType === 'cloud' && deviceStatus) {
                            if (call.method === 'Number.GetStatus' && call.params?.id !== undefined) {
                                const key = `number:${call.params.id}`;
                                if (deviceStatus[key]) {
                                    return { key: call.key, success: true, data: deviceStatus[key] };
                                }
                            }
                            if (call.method === 'Text.GetStatus' && call.params?.id !== undefined) {
                                const key = `text:${call.params.id}`;
                                if (deviceStatus[key]) {
                                    return { key: call.key, success: true, data: deviceStatus[key] };
                                }
                            }
                            return { key: call.key, success: false, error: 'Component not found in cloud status' };
                        }
                        
                        // Direct mode - RPC call
                        if (connType === 'direct' && call.method) {
                            const data = await callShellyRpc(device, call.method, call.params || {});
                            return { key: call.key, success: true, data };
                        }
                        
                        return { key: call.key, success: false, error: 'Invalid call configuration' };
                        
                    } catch (error) {
                        return { key: call.key, success: false, error: error.message };
                    }
                })
            );
            
            const response = {};
            for (const result of results) {
                response[result.key] = result.success ? result.data : { error: result.error };
            }
            
            if (requests.storeHistory) {
                const pv = response.pv?.value ?? 0;
                const grid = response.grid?.value ?? 0;
                const consumption = response.consumption?.value ?? 0;
                const battery = response.batterySOC?.value ?? 0;
                const batteryPower = response.batteryPower?.value ?? 0;
                const inverterStatus = String(response.inverterStatus?.value || 'idle').toLowerCase();
                const plantId = requests.plant_id || 1;
                
                console.log(`storeHistory - values: PV=${pv}, Grid=${grid}, Cons=${consumption}, Bat=${battery}, BatPwr=${batteryPower}, Status=${inverterStatus}, Plant=${plantId}`);
                
                if (pv !== 0 || grid !== 0 || consumption !== 0) {
                    storeReading(pv, grid, consumption, battery, batteryPower, plantId, inverterStatus);
                    response._stored = true;
                } else {
                    response._stored = false;
                }
            }
            
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(response));
            
        } catch (error) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: error.message }));
        }
    });
}

// Helper to get value from device status by path
// Supports formats:
//   "em:0.total_act_power" -> obj["em:0"]["total_act_power"]
//   "em0:total_act_power" -> tries obj["em:0"]["total_act_power"] or obj["em0"]["total_act_power"]
//   "switch:0.apower" -> obj["switch:0"]["apower"]
//   "number:200.value" -> obj["number:200"]["value"]
function getValueByPath(obj, path) {
    if (!obj || !path) return null;
    
    console.log(`getValueByPath: Looking for "${path}" in:`, Object.keys(obj).slice(0, 20));
    
    // Normalize the path - handle "em0:property" format by converting to "em:0.property"
    let normalizedPath = path;
    
    // Pattern: component_name + number + : + property (e.g., "em0:total_act_power")
    const match = path.match(/^([a-zA-Z]+)(\d+):(.+)$/);
    if (match) {
        // Convert "em0:total_act_power" to "em:0.total_act_power"
        normalizedPath = `${match[1]}:${match[2]}.${match[3]}`;
        console.log(`Normalized path: "${path}" -> "${normalizedPath}"`);
    }
    
    // Now parse the normalized path
    // Expected format: "component:id.property" or "component:id.nested.property"
    const colonIdx = normalizedPath.indexOf(':');
    if (colonIdx > 0) {
        const componentName = normalizedPath.substring(0, colonIdx);
        const rest = normalizedPath.substring(colonIdx + 1);
        const dotIdx = rest.indexOf('.');
        
        if (dotIdx > 0) {
            const componentId = rest.substring(0, dotIdx);
            const propertyPath = rest.substring(dotIdx + 1);
            const fullKey = `${componentName}:${componentId}`;
            
            console.log(`Looking for key "${fullKey}" with property "${propertyPath}"`);
            
            if (obj[fullKey]) {
                // Navigate nested properties
                const props = propertyPath.split('.');
                let value = obj[fullKey];
                for (const prop of props) {
                    if (value === null || value === undefined) return null;
                    value = value[prop];
                }
                console.log(`Found value:`, value);
                return value;
            }
        } else {
            // No dot - just "component:id" - return the whole object or a default property
            const fullKey = `${componentName}:${rest}`;
            if (obj[fullKey]) {
                // For number/text components, return .value by default
                if (obj[fullKey].value !== undefined) {
                    return obj[fullKey].value;
                }
                return obj[fullKey];
            }
        }
    }
    
    // Fallback: try direct key access
    if (obj[path] !== undefined) {
        return obj[path];
    }
    
    // Fallback: try dot notation
    const parts = path.split('.');
    let current = obj;
    for (const part of parts) {
        if (current === null || current === undefined) return null;
        if (current[part] !== undefined) {
            current = current[part];
        } else {
            return null;
        }
    }
    
    return current;
}

// Shelly RPC call - supports both direct and cloud connection
function callShellyRpc(ip, method, params = {}, authKey = null) {
    return new Promise((resolve, reject) => {
        const queryParams = new URLSearchParams();
        for (const [key, value] of Object.entries(params)) {
            queryParams.append(key, value);
        }
        
        const queryString = queryParams.toString();
        const reqPath = `/rpc/${method}${queryString ? '?' + queryString : ''}`;
        
        const options = {
            hostname: ip,
            port: 80,
            path: reqPath,
            method: 'GET',
            timeout: 10000,
            headers: {}
        };
        
        if (authKey) {
            options.headers['Authorization'] = `Basic ${Buffer.from(':' + authKey).toString('base64')}`;
        }
        
        const req = http.request(options, (response) => {
            let data = '';
            response.on('data', chunk => data += chunk);
            response.on('end', () => {
                try { resolve(JSON.parse(data)); } 
                catch (e) { reject(new Error(`Invalid JSON: ${data.substring(0, 100)}`)); }
            });
        });
        
        req.on('error', error => reject(new Error(`Request failed: ${error.message}`)));
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
        req.end();
    });
}

// Shelly Cloud API call
function callShellyCloud(cloudServer, deviceId, authKey) {
    return new Promise((resolve, reject) => {
        const https = require('https');
        
        const postData = `id=${deviceId}&auth_key=${authKey}`;
        
        const options = {
            hostname: cloudServer,
            port: 443,
            path: '/device/status',
            method: 'POST',
            timeout: 15000,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        
        const req = https.request(options, (response) => {
            let data = '';
            response.on('data', chunk => data += chunk);
            response.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    if (result.isok && result.data) {
                        resolve(result.data);
                    } else {
                        reject(new Error(result.errors?.join(', ') || 'Cloud request failed'));
                    }
                } catch (e) {
                    reject(new Error(`Invalid JSON: ${data.substring(0, 200)}`));
                }
            });
        });
        
        req.on('error', error => reject(new Error(`Cloud request failed: ${error.message}`)));
        req.on('timeout', () => { req.destroy(); reject(new Error('Cloud timeout')); });
        
        req.write(postData);
        req.end();
    });
}

// ============================================
// BACKGROUND DATA FETCHING (Multi-Plant)
// ============================================
let backgroundFetchTimer = null;
const FETCH_INTERVAL = 10000; // 10 seconds

// Fetch data for all plants
async function backgroundFetchAllPlants() {
    try {
        const plants = db.prepare('SELECT id, name, config FROM plants').all();
        
        for (const plant of plants) {
            try {
                const config = JSON.parse(plant.config || '{}');
                
                // Check if plant has cloud sources
                const hasCloudSources = config.sources && 
                    Object.values(config.sources).some(s => s.connType === 'cloud' && s.device);
                
                // Check if plant has direct sources
                const hasDirectSources = config.sources && 
                    Object.values(config.sources).some(s => s.connType === 'direct' && s.device);
                
                if (hasCloudSources && config.cloudAccessToken) {
                    await fetchFromCloud(plant.id, plant.name, config);
                } else if (hasDirectSources) {
                    await fetchFromDirect(plant.id, plant.name, config);
                }
            } catch (error) {
                console.error(`[BG] Plant ${plant.id} fetch error:`, error.message);
            }
        }
    } catch (error) {
        console.error('[BG] Background fetch error:', error.message);
    }
}

// Fetch from Shelly Cloud HTTP API
async function fetchFromCloud(plantId, plantName, config) {
    const { cloudServer, cloudAccessToken, cloudRefreshToken, sources } = config;
    
    if (!cloudServer || !cloudAccessToken) return;
    
    // Log all sources for debugging
    console.log(`[BG] Plant ${plantId} sources:`, JSON.stringify(Object.entries(sources).map(([k,v]) => ({key: k, connType: v.connType, device: v.device?.substring(0,8), componentId: v.componentId}))));
    
    // Get unique device IDs
    const deviceIds = [...new Set(
        Object.values(sources)
            .filter(s => s.connType === 'cloud' && s.device)
            .map(s => s.device)
    )];
    
    if (deviceIds.length === 0) return;
    
    const data = { pv: 0, grid: 0, consumption: 0, batterySoc: 0, batteryPower: 0, inverterStatus: 'idle' };
    
    for (let i = 0; i < deviceIds.length; i++) {
        const deviceId = deviceIds[i];
        
        // Add delay between device requests to avoid rate limiting (1 req/sec limit)
        if (i > 0) {
            await new Promise(resolve => setTimeout(resolve, 1100)); // 1.1 second delay
        }
        
        try {
            // Call Shelly Cloud API for device status
            const response = await fetch(`https://${cloudServer}/device/status?id=${deviceId}`, {
                headers: { 'Authorization': `Bearer ${cloudAccessToken}` },
                signal: AbortSignal.timeout(5000)
            });
            
            if (response.status === 401) {
                // Token expired - try to refresh
                console.log(`[BG] Plant ${plantId}: Token expired, refreshing...`);
                const newToken = await refreshCloudToken(plantId, cloudServer, cloudRefreshToken);
                if (newToken) {
                    // Retry with new token
                    return fetchFromCloud(plantId, plantName, { ...config, cloudAccessToken: newToken });
                }
                return;
            }
            
            if (!response.ok) {
                console.error(`[BG] Plant ${plantId}: Cloud API error ${response.status}`);
                continue;
            }
            
            const result = await response.json();
            const deviceStatus = result.data?.device_status || {};
            
            // Log device status keys for debugging
            console.log(`[BG] Plant ${plantId}: Device ${deviceId} status keys:`, Object.keys(deviceStatus).slice(0, 15));
            
            // Extract values based on sources config
            for (const [key, src] of Object.entries(sources)) {
                if (src.connType !== 'cloud' || src.device !== deviceId) continue;
                
                let value = null;
                
                if (src.sourceType === 'number') {
                    const numStatus = deviceStatus[`number:${src.componentId}`];
                    value = numStatus?.value;
                } else if (src.sourceType === 'text') {
                    const textStatus = deviceStatus[`text:${src.componentId}`];
                    value = textStatus?.value;
                } else if (src.sourceType === 'path') {
                    console.log(`[BG] Plant ${plantId}: Looking up path '${src.componentId}' in deviceStatus`);
                    value = getNestedValue(deviceStatus, src.componentId);
                    console.log(`[BG] Plant ${plantId}: Path result = ${value}`);
                }
                
                if (value !== null && value !== undefined) {
                    const numValue = parseFloat(value) || 0;
                    console.log(`[BG] Plant ${plantId}: ${key} = ${value} (parsed: ${numValue})`);
                    switch(key) {
                        case 'pv': data.pv = numValue; break;
                        case 'grid': data.grid = numValue; break;
                        case 'consumption': data.consumption = numValue; break;
                        case 'batterySOC': data.batterySoc = numValue; break;
                        case 'batteryPower': data.batteryPower = Math.abs(numValue); break;
                        case 'inverterStatus': data.inverterStatus = String(value).toLowerCase(); break;
                    }
                } else {
                    console.log(`[BG] Plant ${plantId}: ${key} = NULL/undefined (componentId: ${src.componentId}, sourceType: ${src.sourceType})`);
                }
            }
        } catch (error) {
            console.error(`[BG] Plant ${plantId}: Device ${deviceId} error:`, error.message);
        }
    }
    
    // Store if we have any non-zero data
    if (data.pv !== 0 || data.grid !== 0 || data.consumption !== 0) {
        storeReading(data.pv, data.grid, data.consumption, data.batterySoc, data.batteryPower, plantId, data.inverterStatus);
        console.log(`[BG] ☁️ ${plantName}: PV=${data.pv}W Grid=${data.grid}W Home=${data.consumption}W Bat=${data.batteryPower}W (${data.inverterStatus})`);
    }
}

// Refresh OAuth token
async function refreshCloudToken(plantId, cloudServer, refreshToken) {
    if (!refreshToken) return null;
    
    try {
        const response = await fetch(`https://${cloudServer}/oauth/token`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                grant_type: 'refresh_token',
                refresh_token: refreshToken,
                client_id: 'shelly-diy'
            }),
            signal: AbortSignal.timeout(5000)
        });
        
        if (!response.ok) {
            console.error(`[BG] Token refresh failed: ${response.status}`);
            return null;
        }
        
        const data = await response.json();
        const newAccessToken = data.access_token;
        const newRefreshToken = data.refresh_token || refreshToken;
        
        // Update plant config with new tokens
        const plant = statements.getPlantById.get(plantId);
        if (plant) {
            const config = JSON.parse(plant.config || '{}');
            config.cloudAccessToken = newAccessToken;
            config.cloudRefreshToken = newRefreshToken;
            db.prepare('UPDATE plants SET config = ? WHERE id = ?').run(JSON.stringify(config), plantId);
            console.log(`[BG] Plant ${plantId}: Token refreshed successfully`);
        }
        
        return newAccessToken;
    } catch (error) {
        console.error(`[BG] Token refresh error:`, error.message);
        return null;
    }
}

// Fetch from direct Shelly device (local IP)
async function fetchFromDirect(plantId, plantName, config) {
    const { sources } = config;
    
    // Get unique device IPs
    const deviceIps = [...new Set(
        Object.values(sources)
            .filter(s => s.connType === 'direct' && s.device)
            .map(s => s.device)
    )];
    
    if (deviceIps.length === 0) return;
    
    const data = { pv: 0, grid: 0, consumption: 0, batterySoc: 0, batteryPower: 0, inverterStatus: 'idle' };
    
    for (const deviceIp of deviceIps) {
        for (const [key, src] of Object.entries(sources)) {
            if (src.connType !== 'direct' || src.device !== deviceIp) continue;
            
            try {
                let method, params;
                if (src.sourceType === 'number') {
                    method = 'Number.GetStatus';
                    params = { id: parseInt(src.componentId) };
                } else if (src.sourceType === 'text') {
                    method = 'Text.GetStatus';
                    params = { id: parseInt(src.componentId) };
                } else {
                    continue;
                }
                
                const result = await callShellyRpc(deviceIp, method, params);
                const value = result?.value;
                const numValue = parseFloat(value) || 0;
                
                switch(key) {
                    case 'pv': data.pv = numValue; break;
                    case 'grid': data.grid = numValue; break;
                    case 'consumption': data.consumption = numValue; break;
                    case 'batterySOC': data.batterySoc = numValue; break;
                    case 'batteryPower': data.batteryPower = Math.abs(numValue); break;
                    case 'inverterStatus': data.inverterStatus = String(value).toLowerCase(); break;
                }
            } catch (error) {
                // Silent fail for individual components
            }
        }
    }
    
    // Store if we have any non-zero data
    if (data.pv !== 0 || data.grid !== 0 || data.consumption !== 0) {
        storeReading(data.pv, data.grid, data.consumption, data.batterySoc, data.batteryPower, plantId, data.inverterStatus);
        console.log(`[BG] 📡 ${plantName}: PV=${data.pv}W Grid=${data.grid}W Home=${data.consumption}W Bat=${data.batteryPower}W (${data.inverterStatus})`);
    }
}

// Helper: Get nested value from object by path (e.g., "em:0.total_act_power")
function getNestedValue(obj, path) {
    if (!obj || !path) return null;
    
    // Handle format: "em:0.total_act_power" -> obj["em:0"]["total_act_power"]
    const colonIdx = path.indexOf(':');
    if (colonIdx > 0) {
        const rest = path.substring(colonIdx + 1);  // "0.total_act_power"
        const dotIdx = rest.indexOf('.');
        
        if (dotIdx > 0) {
            const compName = path.substring(0, colonIdx);  // "em"
            const compId = rest.substring(0, dotIdx);      // "0"
            const prop = rest.substring(dotIdx + 1);       // "total_act_power"
            const fullKey = `${compName}:${compId}`;       // "em:0"
            
            if (obj[fullKey] && obj[fullKey][prop] !== undefined) {
                return obj[fullKey][prop];
            }
            
            // Try nested property (prop might be "a.b")
            if (obj[fullKey]) {
                const propParts = prop.split('.');
                let current = obj[fullKey];
                for (const p of propParts) {
                    if (current === null || current === undefined) break;
                    current = current[p];
                }
                if (current !== undefined) return current;
            }
        } else {
            // Just "em:0" - return the whole object or its value
            const fullKey = path;
            if (obj[fullKey]?.value !== undefined) return obj[fullKey].value;
            if (obj[fullKey] !== undefined) return obj[fullKey];
        }
    }
    
    // Fallback: simple dot notation
    const parts = path.split('.');
    let current = obj;
    for (const part of parts) {
        if (current === null || current === undefined) return null;
        current = current[part];
    }
    return current;
}

function startBackgroundFetching() {
    console.log(`[BG] Starting background fetch every ${FETCH_INTERVAL/1000}s for all plants`);
    
    // Initial fetch after 5 seconds (allow server to fully start)
    setTimeout(() => {
        backgroundFetchAllPlants();
        backgroundFetchTimer = setInterval(backgroundFetchAllPlants, FETCH_INTERVAL);
    }, 5000);
}

// Process peaks for today on startup (catches up missed windows)
function processStartupPeaks() {
    try {
        // Get all plants
        const plants = db.prepare('SELECT id FROM plants').all();
        if (plants.length === 0) {
            // Create default plant if none exist
            plants.push({ id: 1 });
        }
        
        const now = Math.floor(Date.now() / 1000);
        const startOfDay = getStartOfLocalDay();
        const lastCompletedWindow = getLastCompletedWindowEnd(now);
        
        let totalProcessed = 0;
        
        plants.forEach(plant => {
            const plantId = plant.id;
            
            // Initialize lastProcessedWindow for this plant
            lastProcessedWindows[plantId] = startOfDay;
            
            // Process each 15-min window from start of day until now
            let windowEnd = startOfDay + (15 * 60); // First window ends at 00:15
            let processedCount = 0;
            
            while (windowEnd <= lastCompletedWindow) {
                const windowStart = windowEnd - (15 * 60);
                const readings = statements.getRawByTimeRange.all(plantId, windowStart, windowEnd);
                
                if (readings.length > 0) {
                    let sumPv = 0, sumGrid = 0, sumCons = 0;
                    readings.forEach(r => {
                        sumPv += r.pv_power || 0;
                        sumGrid += Math.abs(r.grid_power || 0);
                        sumCons += r.consumption || 0;
                    });
                    
                    const avgPv = sumPv / readings.length;
                    const avgGrid = sumGrid / readings.length;
                    const avgCons = sumCons / readings.length;
                    
                    const timeStr = getLocalTime(windowEnd * 1000);
                    const dateStr = getLocalDate(windowEnd * 1000);
                    
                    statements.upsertPeak.run(plantId, dateStr, avgPv, timeStr, avgGrid, timeStr, avgCons, timeStr);
                    processedCount++;
                }
                
                lastProcessedWindows[plantId] = windowEnd;
                windowEnd += 15 * 60;
            }
            
            totalProcessed += processedCount;
        });
        
        console.log(`[${getLocalDatetime()}] Startup: Processed ${totalProcessed} peak windows for ${plants.length} plants, timezone=${CONFIG.timezone}`);
    } catch (error) {
        console.error('Failed to process startup peaks:', error);
    }
}

// Start server
server.listen(CONFIG.port, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║     Shelly Proxy Server v4 (SQLite + Auth + Auto-Fetch)    ║
╠════════════════════════════════════════════════════════════╣
║  Port: ${CONFIG.port.toString().padEnd(50)}║
╠════════════════════════════════════════════════════════════╣
║  Auth Endpoints:                                           ║
║    POST /api/auth/register - Register new user             ║
║    POST /api/auth/login    - Login                         ║
║    GET  /api/auth/me       - Get current user              ║
║    GET  /api/auth/status   - Check if setup needed         ║
╠════════════════════════════════════════════════════════════╣
║  Data Endpoints:                                           ║
║    /health, /api/history, /api/daily, /api/daily-stats     ║
║    /api/config (requires auth), /api/peaks                 ║
╚════════════════════════════════════════════════════════════╝
    `);
    
    // Populate cache from database on startup for instant home page loading
    populateCacheFromDatabase();
    
    processStartupPeaks();
    startBackgroundFetching();
});

// Populate in-memory cache from database (for fast home page loading after restart)
function populateCacheFromDatabase() {
    try {
        const plants = db.prepare('SELECT id FROM plants').all();
        for (const plant of plants) {
            const latest = statements.getLatestReading.get(plant.id);
            if (latest) {
                latestReadingsCache[plant.id] = {
                    timestamp: latest.timestamp,
                    pv_power: latest.pv_power || 0,
                    grid_power: latest.grid_power || 0,
                    consumption: latest.consumption || 0,
                    battery_soc: latest.battery_soc || 0,
                    battery_power: latest.battery_power || 0
                };
                console.log(`[Cache] Loaded latest reading for plant ${plant.id} from database`);
            }
        }
    } catch (error) {
        console.error('[Cache] Failed to populate cache from database:', error);
    }
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down...');
    if (backgroundFetchTimer) clearInterval(backgroundFetchTimer);
    db.close();
    server.close(() => process.exit(0));
});

process.on('SIGTERM', () => {
    if (backgroundFetchTimer) clearInterval(backgroundFetchTimer);
    db.close();
    server.close(() => process.exit(0));
});
